#!/bin/bash
sudo cp -a fileshare/. /var/www/modules/en-file_share/